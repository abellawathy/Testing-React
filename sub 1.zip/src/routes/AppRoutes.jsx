import React from 'react'
import { Routes, Route } from 'react-router-dom'

import HomePage from '../pages/HomePage'
import LoginPage from '../pages/LoginPage'
import RegisterPage from '../pages/RegisterPage'
import ThreadDetailPage from '../pages/ThreadDetailPage'
import CreateThreadPage from '../pages/CreateThreadPage'
import LeaderboardPage from '../pages/LeaderboardPage'

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/threads/:id" element={<ThreadDetailPage />} />
      <Route path="/create" element={<CreateThreadPage />} />
      <Route path="/leaderboard" element={<LeaderboardPage />} />
    </Routes>
  )
}

export default AppRoutes