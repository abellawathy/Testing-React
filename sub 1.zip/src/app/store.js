import { createStore, applyMiddleware, combineReducers } from 'redux'
import { thunk } from 'redux-thunk'

import authReducer from '../states/auth/reducer'
import threadsReducer from '../states/threads/reducer'
import threadDetailReducer from '../states/threadDetail/reducer'
import usersReducer from '../states/users/reducer'
import leaderboardReducer from '../states/leaderboard/reducer'
import loadingReducer from '../states/loading/reducer'

const rootReducer = combineReducers({
  auth: authReducer,
  threads: threadsReducer,
  threadDetail: threadDetailReducer,
  users: usersReducer,
  leaderboard: leaderboardReducer,
  loading: loadingReducer,
})

const store = createStore(rootReducer, applyMiddleware(thunk))

export default store